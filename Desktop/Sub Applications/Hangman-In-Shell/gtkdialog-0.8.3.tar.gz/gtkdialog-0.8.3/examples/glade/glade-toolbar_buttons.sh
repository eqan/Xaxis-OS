#!/bin/sh

gtkdialog --glade-xml=glade-toolbar_buttons.glade \
          --program=MAIN_WINDOW
